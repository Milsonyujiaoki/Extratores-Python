# Arquivo __init__.py para tornar config um pacote Python válido
